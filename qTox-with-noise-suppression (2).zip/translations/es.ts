<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="es_MX">
<context>
    <name>AVForm</name>
    <message>
        <source>Audio/Video</source>
        <translation>Audio/Vídeo</translation>
    </message>
    <message>
        <source>Default resolution</source>
        <translation>Resolución predeterminada</translation>
    </message>
    <message>
        <source>Disabled</source>
        <translation>Deshabilitado</translation>
    </message>
    <message>
        <source>Select region</source>
        <translation>Seleccionar región</translation>
    </message>
    <message>
        <source>Screen %1</source>
        <translation>Pantalla %1</translation>
    </message>
    <message>
        <source>Audio Settings</source>
        <translation>Opciones de audio</translation>
    </message>
    <message>
        <source>Gain</source>
        <translation>Ganancia</translation>
    </message>
    <message>
        <source>Playback device</source>
        <translation>Dispositivo de reproducción</translation>
    </message>
    <message>
        <source>Capture device</source>
        <translation>Dispositivo de captura</translation>
    </message>
    <message>
        <source>Volume</source>
        <translation>Volumen</translation>
    </message>
    <message>
        <source>Video Settings</source>
        <translation>Opciones de vídeo</translation>
    </message>
    <message>
        <source>Video device</source>
        <translation>Dispositivo de vídeo</translation>
    </message>
    <message>
        <source>Set resolution of your camera.
The higher values, the better video quality your friends may get.
Note though that with better video quality there is needed better internet connection.
Sometimes your connection may not be good enough to handle higher video quality,
which may lead to problems with video calls.</source>
        <translation>Establezca la resolución de la cámara.
Valores más altos mejoran la calidad de vídeo que tus amigos pueden ver.
Ten en cuenta que una mejor calidad de vídeo requiere una mejor conexión a Internet.
Si tu conexión no es suficiente para soportar una calidad de vídeo alta,
se pueden producir problemas con las videollamadas.</translation>
    </message>
    <message>
        <source>Resolution</source>
        <translation>Resolución</translation>
    </message>
    <message>
        <source>Rescan devices</source>
        <translation>Volver a detectar dispositivos</translation>
    </message>
    <message>
        <source>Test Sound</source>
        <translation>Comprobar sonido</translation>
    </message>
    <message>
        <source>Audio quality</source>
        <translation>Calidad de audio</translation>
    </message>
    <message>
        <source>High (64 kBps)</source>
        <translation>Alto (64 kBps)</translation>
    </message>
    <message>
        <source>Medium (32 kBps)</source>
        <translation>Medio (32 kBps)</translation>
    </message>
    <message>
        <source>Low (16 kBps)</source>
        <translation>Bajo (16 kBps)</translation>
    </message>
    <message>
        <source>Very low (8 kBps)</source>
        <translation>Muy bajo (8 kBps)</translation>
    </message>
    <message>
        <source>Threshold</source>
        <translation>Límite</translation>
    </message>
    <message>
        <source>Use slider to set the volume of your speakers.</source>
        <translation>Utilice el control deslizante para configurar el volumen de sus altavoces.</translation>
    </message>
    <message>
        <source>Transmitted audio quality. Lower this setting if your bandwidth is not high enough or if you want to reduce bandwidth usage.</source>
        <translation>Calidad del audio transmitido. Reduzca este ajuste si su ancho de banda no es lo suficientemente alto o si desea reducir el uso del ancho de banda.</translation>
    </message>
    <message>
        <source>Set resolution of your camera.
The higher values, the better video quality your friends may get.
Note that with better video quality, you use more bandwidth.
Sometimes your connection may not be good enough to handle higher video quality,
which may lead to problems with video calls.</source>
        <translation>Ajusta la resolución de tu cámara.
Cuanto más altos sean los valores, mejor calidad de vídeo podrán obtener tus amigos.
Ten en cuenta que con una mejor calidad de vídeo, utilizas más ancho de banda.
A veces tu conexión puede no ser lo suficientemente buena para manejar una calidad de vídeo más alta,
lo que puede provocar problemas en las videollamadas.</translation>
    </message>
    <message>
        <source>Play a test sound while changing the output volume.</source>
        <translation>Reproduce un sonido de prueba mientras cambia el volumen de salida.</translation>
    </message>
    <message>
        <source>Use slider to set the gain of your input device ranging from %1dB to %2dB.</source>
        <translation>Utilice el control deslizante para ajustar la ganancia de su dispositivo de entrada, que va de %1dB a %2dB.</translation>
    </message>
    <message>
        <source>Use slider to set the activation volume for your input device.</source>
        <translation>Utilice el control deslizante para ajustar el volumen de activación de su dispositivo de entrada.</translation>
    </message>
</context>
<context>
    <name>AboutForm</name>
    <message>
        <source>About</source>
        <translation>Acerca de</translation>
    </message>
    <message>
        <source>Original author: %1</source>
        <translation>Autor original: %1</translation>
    </message>
    <message>
        <source>You are using qTox version %1.</source>
        <translation>Está usando qTox versión %1.</translation>
    </message>
    <message>
        <source>Commit hash: %1</source>
        <translation>Confirmación de hash: %1</translation>
    </message>
    <message>
        <source>toxcore version: %1</source>
        <translation>Versión de toxcore: %1</translation>
    </message>
    <message>
        <source>Qt version: %1</source>
        <translation>Versión de Qt: %1</translation>
    </message>
    <message>
        <source>A list of all known issues may be found at our %1 at Github. If you discover a bug or security vulnerability within qTox, please report it according to the guidelines in our %2 wiki article.</source>
        <comment>`%1` is replaced by translation of `bug tracker`
`%2` is replaced by translation of `Writing Useful Bug Reports`</comment>
        <translation>Puedes encontrar una lista de los problemas conocidos en nuestro %1 en GitHub. Si encuentras un error o una vulnerabilidad de seguridad en qTox, por favor repórtalo de acuerdo a las directrices en nuestro artículo de la wiki %2.</translation>
    </message>
    <message>
        <source>Click here to report a bug.</source>
        <translation>Clic aquí para reportar un error.</translation>
    </message>
    <message>
        <source>See a full list of %1 at Github</source>
        <comment>`%1` is replaced with translation of word `contributors`</comment>
        <translation>Lista completa de %1 en Github</translation>
    </message>
    <message>
        <source>bug-tracker</source>
        <comment>Replaces `%1` in the `A list of all known…`</comment>
        <translation>Seguimiento de errores</translation>
    </message>
    <message>
        <source>Writing Useful Bug Reports</source>
        <comment>Replaces `%2` in the `A list of all known…`</comment>
        <translation>Escribiendo informes de errores útiles</translation>
    </message>
    <message>
        <source>contributors</source>
        <comment>Replaces `%1` in `See a full list of…`</comment>
        <translation>contribuidores</translation>
    </message>
    <message>
        <source>This version of qTox is being maintained by the TokTok team following the archiving of the original qTox project.</source>
        <translation>Esta versión de qTox está siendo mantenida por el equipo de TokTok tras el archivo del proyecto qTox original.</translation>
    </message>
</context>
<context>
    <name>AboutFriendForm</name>
    <message>
        <source>Automatically accept files from contact if set</source>
        <translation>Aceptar automáticamente archivos de los contactos si esta establecido</translation>
    </message>
    <message>
        <source>Default directory to save files:</source>
        <translation>Directorio predeterminado para guardar archivos:</translation>
    </message>
    <message>
        <source>Manual</source>
        <translation>Manual</translation>
    </message>
    <message>
        <source>Audio</source>
        <translation>Audio</translation>
    </message>
    <message>
        <source>Audio + Video</source>
        <translation>Audio y vídeo</translation>
    </message>
    <message>
        <source>Automatically accept conference invitations from this contact if set.</source>
        <translation>Aceptar automáticamente invitaciones a grupos de este contacto si esta establecido.</translation>
    </message>
    <message>
        <source>Remove history (operation can not be undone!)</source>
        <translation>Eliminar historial (¡no se puede deshacer!)</translation>
    </message>
    <message>
        <source>Notes</source>
        <translation>Notas</translation>
    </message>
    <message>
        <source>Input field for notes about the contact</source>
        <translation>Campo para introducir notas sobre el contacto</translation>
    </message>
    <message>
        <source>History removed</source>
        <translation>Historial eliminado</translation>
    </message>
    <message>
        <source>This is the public key of your friend, use it to verify their identity via another channel. You can not send this to other people so they can add this contact.</source>
        <translation>Esta es la clave pública de su amigo, utilícela para verificar su identidad a través de otro canal. No puedes enviarla a otras personas para que puedan agregar este contacto.</translation>
    </message>
    <message>
        <source>Public key (not ToxID):</source>
        <translation>Clave pública (no el ToxID):</translation>
    </message>
    <message>
        <source>Confirmation</source>
        <translation>Confirmación</translation>
    </message>
    <message>
        <source>Are you sure to remove %1 chat history?</source>
        <translation>¿Estás seguro de eliminar %1 historial de chat?</translation>
    </message>
    <message>
        <source>Failed to remove chat history with %1!</source>
        <translation>¡Error al eliminar el historial de chat con %1!</translation>
    </message>
    <message>
        <source>Auto-accept files</source>
        <translation>Aceptar archivos automáticamente</translation>
    </message>
    <message>
        <source>Auto-accept for this contact is disabled</source>
        <translation>Recepción automática deshabilitada para este contacto</translation>
    </message>
    <message>
        <source>Auto-accept call:</source>
        <translation>Aceptar llamadas automáticamente:</translation>
    </message>
    <message>
        <source>Auto-accept conference invites</source>
        <translation>Aceptar automáticamente invitaciones a grupos</translation>
    </message>
    <message>
        <source>You can save comments about this contact here.</source>
        <translation>Puedes guardar comentarios acerca de este contacto aquí.</translation>
    </message>
</context>
<context>
    <name>AboutSettings</name>
    <message>
        <source>Version</source>
        <translation>Versión</translation>
    </message>
    <message>
        <source>License</source>
        <translation>Licencia</translation>
    </message>
    <message>
        <source>Authors</source>
        <translation>Autores</translation>
    </message>
    <message>
        <source>Known Issues</source>
        <translation>Problemas conocidos</translation>
    </message>
    <message>
        <source>Open update download link</source>
        <translation>Abrir enlace de descarga de actualización</translation>
    </message>
    <message>
        <source>Update available</source>
        <translation>Actualización disponible</translation>
    </message>
    <message>
        <source>qTox is up to date ✓</source>
        <translation>qTox está actualizado ✓</translation>
    </message>
    <message>
        <source>Currently running an untested/unstable version of qTox</source>
        <translation>Actualmente ejecutando una versión no probada/inestable de qTox</translation>
    </message>
</context>
<context>
    <name>AddFriendForm</name>
    <message>
        <source>Add Friends</source>
        <translation>Agregar amigos</translation>
    </message>
    <message>
        <source>Send friend request</source>
        <translation>Enviar solicitud de amistad</translation>
    </message>
    <message>
        <source>Friend requests</source>
        <translation>Solicitudes de amistad</translation>
    </message>
    <message>
        <source>Accept</source>
        <translation>Aceptar</translation>
    </message>
    <message>
        <source>Reject</source>
        <translation>Rechazar</translation>
    </message>
    <message>
        <source>Couldn&apos;t add friend</source>
        <translation>No se pudo agregar el amigo</translation>
    </message>
    <message>
        <source>Invalid Tox ID format</source>
        <translation>Formato inválido de ID de Tox</translation>
    </message>
    <message>
        <source>Type in Tox ID of your friend</source>
        <translation>Escribe el ID de Tox de tu amigo</translation>
    </message>
    <message>
        <source>Friend request message</source>
        <translation>Mensaje para solicitud de amistad</translation>
    </message>
    <message>
        <source>Type message to send with the friend request or leave empty to send a default message</source>
        <translation>Escribe el mensaje a enviar junto con la petición de amistad o déjalo vacío para enviar el mensaje por defecto</translation>
    </message>
    <message>
        <source>You can&apos;t add yourself as a friend!</source>
        <extracomment>When trying to add your own Tox ID as friend</extracomment>
        <translation>¡No puedes agregarte a ti como amigo!</translation>
    </message>
    <message>
        <source>Open contact list</source>
        <translation>Abrir lista de contactos</translation>
    </message>
    <message>
        <source>Couldn&apos;t open file</source>
        <translation>No se pudo abrir el archivo</translation>
    </message>
    <message>
        <source>Couldn&apos;t open the contact file</source>
        <extracomment>Error message when trying to open a contact list file to import</extracomment>
        <translation>No se pudo abrir el archivo de contacto</translation>
    </message>
    <message>
        <source>Invalid file</source>
        <translation>Archivo inválido</translation>
    </message>
    <message>
        <source>We couldn&apos;t find any contacts to import in this file!</source>
        <translation>¡No se pudo encontrar ningún contacto para importar en este archivo!</translation>
    </message>
    <message>
        <source>Tox ID</source>
        <extracomment>Tox ID of the person you&apos;re sending a friend request to</extracomment>
        <translation>ID de Tox</translation>
    </message>
    <message>
        <source>Message</source>
        <extracomment>The message you send in friend requests</extracomment>
        <translation>Mensaje</translation>
    </message>
    <message>
        <source>Open</source>
        <extracomment>Button to choose a file with a list of contacts to import</extracomment>
        <translation>Abrir</translation>
    </message>
    <message>
        <source>Send friend requests</source>
        <translation>Enviar solicitudes de amistad</translation>
    </message>
    <message>
        <source>%1 here! Tox me maybe?</source>
        <extracomment>Default message in friend requests if the field is left blank. Write something appropriate!</extracomment>
        <translation>¡Hola, soy %1! ¿Deseas agregarme en Tox?</translation>
    </message>
    <message>
        <source>Import a list of contacts, one Tox ID per line</source>
        <translation>Importar lista de contactos, un ID de Tox por línea</translation>
    </message>
    <message numerus="yes">
        <source>Ready to import %n contact(s), click send to confirm</source>
        <translation>
            <numerusform>Listo para importar %n contacto, clic en enviar para confirmar</numerusform>
            <numerusform>Listo para importar %n contactos, clic en enviar para confirmar</numerusform>
        </translation>
    </message>
    <message>
        <source>Import contacts</source>
        <translation>Importar contactos</translation>
    </message>
    <message>
        <source>Tox ID, 76 hexadecimal characters</source>
        <translation>Tox ID, 76 caracteres hexadecimales</translation>
    </message>
    <message>
        <source>%1 Tox ID is invalid</source>
        <comment>Tox address error</comment>
        <translation>%1 Tox ID no es válido</translation>
    </message>
    <message>
        <source>76 hexadecimal characters</source>
        <extracomment>Tox ID format description</extracomment>
        <translation>76 caracteres hexadecimales</translation>
    </message>
    <message>
        <source>Add friend</source>
        <translation>Agregar amigo</translation>
    </message>
</context>
<context>
    <name>AdvancedForm</name>
    <message>
        <source>Advanced</source>
        <translation>Avanzado</translation>
    </message>
    <message>
        <source>really</source>
        <translation>realmente</translation>
    </message>
    <message>
        <source>not</source>
        <translation>no</translation>
    </message>
    <message>
        <source>IMPORTANT NOTE</source>
        <translation>NOTA IMPORTANTE</translation>
    </message>
    <message>
        <source>Reset settings</source>
        <translation>Restablecer configuración</translation>
    </message>
    <message>
        <source>All settings will be reset to default. Are you sure?</source>
        <translation>La configuración va a ser restablecida a los valores predeterminados. ¿Estás seguro?</translation>
    </message>
    <message>
        <source>Yes</source>
        <translation>Sí</translation>
    </message>
    <message>
        <source>No</source>
        <translation>No</translation>
    </message>
    <message>
        <source>Logs (*.log)</source>
        <translation>Registros (*.log)</translation>
    </message>
    <message>
        <source>Unless you %1 know what you are doing, please do %2 change anything here. Changes made here may lead to problems with qTox, and even to loss of your data, e.g. history.%3</source>
        <translation>A menos que %1 sepas lo que estás haciento, por favor %2 cambies nada aquí. qTox podría empezar a tener problemas e incluso podrías perder datos, como tu historial.%3</translation>
    </message>
    <message>
        <source>Changes here are applied only after restarting qTox.</source>
        <translation>Los cambios aquí se aplican sólo después de reiniciar qTox.</translation>
    </message>
    <message>
        <source>Save file</source>
        <translation>Guardar archivo</translation>
    </message>
    <message>
        <source>Invalid proxy address</source>
        <translation>Dirección proxy no válida</translation>
    </message>
    <message>
        <source>Please enter a valid IP address or hostname for the proxy setting.</source>
        <translation>Ingrese una dirección IP o nombre IP válido para la configuración de proxy.</translation>
    </message>
</context>
<context>
    <name>AdvancedSettings</name>
    <message>
        <source>Save settings to the working directory instead of the usual conf dir</source>
        <extracomment>describes makeToxPortable checkbox</extracomment>
        <translation>Guardar la configuración en el directorio actual en vez del predeterminado</translation>
    </message>
    <message>
        <source>Make Tox portable</source>
        <translatorcomment>No debería ser &quot;Make qTox portable&quot;?</translatorcomment>
        <translation>Hacer Tox portable</translation>
    </message>
    <message>
        <source>Reset to default settings</source>
        <translation>Restablecer configuración predeterminada</translation>
    </message>
    <message>
        <source>Portable</source>
        <translation>Portable</translation>
    </message>
    <message>
        <source>Enable IPv6 (recommended)</source>
        <extracomment>Text on a checkbox to enable IPv6</extracomment>
        <translation>Habilitar IPv6 (recomendado)</translation>
    </message>
    <message>
        <source>Enable UDP (recommended)</source>
        <extracomment>Text on checkbox to disable UDP</extracomment>
        <translation>Habilitar UDP (recomendado)</translation>
    </message>
    <message>
        <source>Proxy type:</source>
        <translation>Tipo de proxy:</translation>
    </message>
    <message>
        <source>Address:</source>
        <extracomment>Text on proxy addr label</extracomment>
        <translation>Dirección:</translation>
    </message>
    <message>
        <source>Port:</source>
        <extracomment>Text on proxy port label</extracomment>
        <translation>Puerto:</translation>
    </message>
    <message>
        <source>None</source>
        <translation>Ninguno</translation>
    </message>
    <message>
        <source>Debug</source>
        <translation>Depurar</translation>
    </message>
    <message>
        <source>Export Debug Log</source>
        <translation>Exportar registro de depuración</translation>
    </message>
    <message>
        <source>Copy Debug Log</source>
        <translation>Copiar registro de depuración</translation>
    </message>
    <message>
        <source>Enable LAN discovery</source>
        <translation>Habilitar la detección de LAN</translation>
    </message>
    <message>
        <source>Connection settings</source>
        <translation>Configuraciones de conexión</translation>
    </message>
    <message>
        <source>Disabling this allows, e.g., Tox over Tor. It adds load to the Tox network however, so uncheck only when necessary.</source>
        <extracomment>force tcp checkbox tooltip</extracomment>
        <translation>Deshabilitar esto permite, por ejemplo, Tox sobre Tor. Sin embargo, agrega carga a la red Tox, así que desmarque solo cuando sea necesario.</translation>
    </message>
    <message>
        <source>Enable Debug Tools (developers only)</source>
        <translation>Activar herramientas de depuración (solo para desarrolladores)</translation>
    </message>
</context>
<context>
    <name>AppManager</name>
    <message>
        <source>Tox URI to parse</source>
        <translation>URI Tox a utilizar</translation>
    </message>
    <message>
        <source>Starts new instance and loads specified profile.</source>
        <translation>Inicia una nueva instancia de qTox y carga el perfil especificado.</translation>
    </message>
    <message>
        <source>profile</source>
        <translation>perfil</translation>
    </message>
    <message>
        <source>Starts new instance and opens the login screen.</source>
        <translation>Inicia una nueva instancia y abre la pantalla de inicio de sesión.</translation>
    </message>
    <message>
        <source>Sets IPv6 &lt;on&gt;/&lt;off&gt;. Default is ON.</source>
        <comment>&apos;on&apos; and &apos;off&apos; should not be translated, they are flag values</comment>
        <translation>Establece IPv6 &lt;on&gt;/&lt;off&gt;. El valor predeterminado es ON.</translation>
    </message>
    <message>
        <source>Sets UDP &lt;on&gt;/&lt;off&gt;. Default is ON.</source>
        <comment>&apos;on&apos; and &apos;off&apos; should not be translated, they are flag values</comment>
        <translation>Establece UDP &lt;on&gt;/&lt;off&gt;. Por defecto es ON.</translation>
    </message>
    <message>
        <source>Sets LAN discovery &lt;on&gt;/&lt;off&gt;. UDP off overrides. Default is ON.</source>
        <comment>&apos;on&apos; and &apos;off&apos; should not be translated, they are flag values</comment>
        <translation>Establece el descubrimiento de LAN &lt;activado&gt;/&lt;desactivado&gt;. UDP deshabilitado elimina esta opción. El valor predeterminado es ACTIVADO.</translation>
    </message>
    <message>
        <source>Sets proxy settings. Default is NONE.</source>
        <comment>NONE should not be translated, it is a flag value</comment>
        <translation>Establece la configuración del proxy. Por defecto es NINGUNO.</translation>
    </message>
    <message>
        <source>Error</source>
        <translation>Error</translation>
    </message>
    <message>
        <source>Failed to load profile automatically.</source>
        <translation>No se pudo cargar el perfil automáticamente.</translation>
    </message>
    <message>
        <source>Checks whether this program is running the latest qTox version.</source>
        <translation>Comprueba si este programa está ejecutando la última versión de qTox.</translation>
    </message>
    <message>
        <source>Starts in portable mode; loads profile from this directory.</source>
        <translation>Comienza en modo portátil; carga el perfil desde este directorio.</translation>
    </message>
    <message>
        <source>path</source>
        <comment>directory in file system</comment>
        <translation>ruta</translation>
    </message>
</context>
<context>
    <name>ChatForm</name>
    <message>
        <source>Send a file</source>
        <translation>Enviar un archivo</translation>
    </message>
    <message>
        <source>qTox wasn&apos;t able to open %1</source>
        <translation>qTox no pudo abrir %1</translation>
    </message>
    <message>
        <source>Unable to open</source>
        <translation>No se pudo abrir</translation>
    </message>
    <message>
        <source>Bad idea</source>
        <translation>Mala idea</translation>
    </message>
    <message>
        <source>Failed to open temporary file</source>
        <comment>Temporary file for screenshot</comment>
        <translation>Error al abrir el archivo temporal</translation>
    </message>
    <message>
        <source>qTox wasn&apos;t able to save the screenshot</source>
        <translation>qTox no pudo guardar la captura de pantalla</translation>
    </message>
    <message>
        <source>Call duration: </source>
        <translation>Duración de la llamada: </translation>
    </message>
    <message>
        <source>Copy</source>
        <translation>Copiar</translation>
    </message>
    <message>
        <source>You&apos;re trying to send a sequential file, which is not going to work!</source>
        <translation>Estás tratando de enviar un archivo consecutivo ¡lo que no va a funcionar!</translation>
    </message>
    <message>
        <source>Filename contained illegal characters</source>
        <translation>Nombre del archivo contenía caracteres no válidos</translation>
    </message>
    <message>
        <source>Illegal characters have been changed to _
so you can save the file on Windows.</source>
        <translation>Los caracteres no válidos fueran cambiados a _
para que puedas guardar el archivo en windows.</translation>
    </message>
</context>
<context>
    <name>ChatFormHeader</name>
    <message>
        <source>Can&apos;t start audio call</source>
        <translation>No se puede iniciar la llamada de audio</translation>
    </message>
    <message>
        <source>Start audio call</source>
        <translation>Iniciar llamada de audio</translation>
    </message>
    <message>
        <source>End audio call</source>
        <translation>Terminar llamada de audio</translation>
    </message>
    <message>
        <source>Cancel audio call</source>
        <translation>Cancelar llamada de audio</translation>
    </message>
    <message>
        <source>Accept audio call</source>
        <translation>Aceptar llamada de audio</translation>
    </message>
    <message>
        <source>Can&apos;t start video call</source>
        <translation>No se puede iniciar la videollamada</translation>
    </message>
    <message>
        <source>Start video call</source>
        <translation>Iniciar videollamada</translation>
    </message>
    <message>
        <source>End video call</source>
        <translation>Terminar videollamada</translation>
    </message>
    <message>
        <source>Cancel video call</source>
        <translation>Cancelar videollamada</translation>
    </message>
    <message>
        <source>Accept video call</source>
        <translation>Aceptar videollamada</translation>
    </message>
    <message>
        <source>Sound can be disabled only during a call</source>
        <translation>El sonido sólo puede ser desactivado durante una llamada</translation>
    </message>
    <message>
        <source>Unmute call</source>
        <translation>Dejar de silenciar llamada</translation>
    </message>
    <message>
        <source>Mute call</source>
        <translation>Silenciar llamada</translation>
    </message>
    <message>
        <source>Microphone can be muted only during a call</source>
        <translation>El micrófono se puede silenciar sólo durante una llamada</translation>
    </message>
    <message>
        <source>Unmute microphone</source>
        <translation>Dejar de silenciar el micrófono</translation>
    </message>
    <message>
        <source>Mute microphone</source>
        <translation>Silenciar micrófono</translation>
    </message>
</context>
<context>
    <name>ChatManager</name>
    <message>
        <source>Conference #%1</source>
        <translation>Grupo #%1</translation>
    </message>
</context>
<context>
    <name>ChatTextEdit</name>
    <message>
        <source>Type your message here...</source>
        <translation>Ingresa tu mensaje aquí...</translation>
    </message>
</context>
<context>
    <name>ChatWidget</name>
    <message>
        <source>pending</source>
        <translation>pendiente</translation>
    </message>
    <message>
        <source>%1 is typing</source>
        <translation>%1 está escribiendo</translation>
    </message>
    <message>
        <source>Copy</source>
        <translation>Copiar</translation>
    </message>
    <message>
        <source>Select all</source>
        <translation>Seleccionar todo</translation>
    </message>
</context>
<context>
    <name>CircleWidget</name>
    <message>
        <source>Rename circle</source>
        <comment>Menu for renaming a circle</comment>
        <translation>Renombrar círculo</translation>
    </message>
    <message>
        <source>Remove circle</source>
        <comment>Menu for removing a circle</comment>
        <translation>Eliminar círculo</translation>
    </message>
    <message>
        <source>Open all in new window</source>
        <translation>Abrir todos en una nueva ventana</translation>
    </message>
</context>
<context>
    <name>CommonDialogs</name>
    <message>
        <source>Location not writable</source>
        <comment>Title of permissions popup</comment>
        <translation>Ubicación no escribible</translation>
    </message>
    <message>
        <source>You do not have permission to write to that location. Choose another, or cancel the save dialog.</source>
        <comment>text of permissions popup</comment>
        <translation>No tienes permiso de escritura. Elige otra ubicación o cancela la operación.</translation>
    </message>
</context>
<context>
    <name>ConferenceForm</name>
    <message numerus="yes">
        <source>%n user(s) in chat</source>
        <comment>Number of users in chat</comment>
        <translation>
            <numerusform>%n usuario en el chat</numerusform>
            <numerusform>%n usuarios en el chat</numerusform>
        </translation>
    </message>
    <message>
        <source>mute</source>
        <translation>mudo</translation>
    </message>
    <message>
        <source>unmute</source>
        <translation>activar el sonido</translation>
    </message>
    <message>
        <source>copy peer ID</source>
        <translation>copiar ID de compañero</translation>
    </message>
</context>
<context>
    <name>ConferenceInviteForm</name>
    <message>
        <source>Conferences</source>
        <translation>Grupos</translation>
    </message>
    <message>
        <source>Create new conference</source>
        <translation>Crear un nuevo grupo</translation>
    </message>
    <message>
        <source>Conference invites</source>
        <translation>Invitaciones a grupos</translation>
    </message>
</context>
<context>
    <name>ConferenceInviteWidget</name>
    <message>
        <source>Invited by %1 on %2 at %3.</source>
        <translation>Invitado por %1 en %2 a %3.</translation>
    </message>
    <message>
        <source>Join</source>
        <translation>Unirse</translation>
    </message>
    <message>
        <source>Decline</source>
        <translation>Rechazar</translation>
    </message>
</context>
<context>
    <name>ConferenceWidget</name>
    <message>
        <source>Set title...</source>
        <translation>Establecer título...</translation>
    </message>
    <message>
        <source>Open chat in new window</source>
        <translation>Abrir chat en una nueva ventana</translation>
    </message>
    <message>
        <source>Remove chat from this window</source>
        <translation>Quitar chat de esta ventana</translation>
    </message>
    <message>
        <source>Quit conference</source>
        <comment>Menu to quit a conference</comment>
        <translation>Dejar el grupo</translation>
    </message>
    <message numerus="yes">
        <source>%n user(s) in chat</source>
        <comment>Number of users in chat</comment>
        <translation>
            <numerusform>%n usuario en el chat</numerusform>
            <numerusform>%n usuarios en el chat</numerusform>
        </translation>
    </message>
    <message>
        <source>New message</source>
        <translation>Nuevo Mensaje</translation>
    </message>
    <message>
        <source>Online</source>
        <translation>Conectado</translation>
    </message>
</context>
<context>
    <name>Core</name>
    <message>
        <source>/me offers friendship, &quot;%1&quot;</source>
        <translation>/me ofrece amistad, &quot;%1&quot;</translation>
    </message>
    <message>
        <source>Conference %1</source>
        <translation>Grupo %1</translation>
    </message>
    <message>
        <source>Invalid Tox ID</source>
        <comment>Error while sending friend request</comment>
        <translation>ID de Tox inválida</translation>
    </message>
    <message>
        <source>You need to write a message with your request</source>
        <comment>Error while sending friend request</comment>
        <translation>Tienes que escribir un mensaje para la solicitud</translation>
    </message>
    <message>
        <source>Your message is too long!</source>
        <comment>Error while sending friend request</comment>
        <translation>¡Tu mensaje es demasiado largo!</translation>
    </message>
    <message>
        <source>Friend is already added</source>
        <comment>Error while sending friend request</comment>
        <translation>Amigo ya fue agregado</translation>
    </message>
</context>
<context>
    <name>DebugLog</name>
    <message>
        <source>Debug Log</source>
        <translation>Registro de depuración</translation>
    </message>
    <message>
        <source>Auto-reload</source>
        <translation>Recarga automática</translation>
    </message>
    <message>
        <source>Auto-scroll</source>
        <translation>Desplazamiento automático</translation>
    </message>
</context>
<context>
    <name>DebugLogForm</name>
    <message>
        <source>Debug Log</source>
        <translation>Registro de depuración</translation>
    </message>
</context>
<context>
    <name>FileTransferWidget</name>
    <message>
        <source>Waiting to send...</source>
        <comment>file transfer widget</comment>
        <translation>Envío en espera...</translation>
    </message>
    <message>
        <source>Accept to receive this file</source>
        <comment>file transfer widget</comment>
        <translation>Presiona aceptar para recibir este archivo</translation>
    </message>
    <message>
        <source>Resuming...</source>
        <comment>file transfer widget</comment>
        <translation>Reanudando...</translation>
    </message>
    <message>
        <source>Cancel transfer</source>
        <translation>Cancelar transferencia</translation>
    </message>
    <message>
        <source>Pause transfer</source>
        <translation>Pausar transferencia</translation>
    </message>
    <message>
        <source>Paused</source>
        <comment>file transfer widget</comment>
        <translation>En pausa</translation>
    </message>
    <message>
        <source>Open file</source>
        <translation>Abrir archivo</translation>
    </message>
    <message>
        <source>Open file directory</source>
        <translation>Abrir directorio del archivo</translation>
    </message>
    <message>
        <source>Resume transfer</source>
        <translation>Reanudar transferencia</translation>
    </message>
    <message>
        <source>Accept transfer</source>
        <translation>Aceptar transferencia</translation>
    </message>
    <message>
        <source>Save a file</source>
        <comment>Title of the file saving dialog</comment>
        <translation>Guardar un archivo</translation>
    </message>
    <message>
        <source>Remote paused</source>
        <comment>file transfer widget</comment>
        <translation>Remoto pausado</translation>
    </message>
</context>
<context>
    <name>FilesForm</name>
    <message>
        <source>Downloads</source>
        <translation>Descargas</translation>
    </message>
    <message>
        <source>Uploads</source>
        <translation>Subidas</translation>
    </message>
    <message>
        <source>Transferred files</source>
        <comment>&quot;Headline&quot; of the window</comment>
        <translation>Archivos transferidos</translation>
    </message>
</context>
<context>
    <name>FriendListWidget</name>
    <message>
        <source>Today</source>
        <translation>Hoy</translation>
    </message>
    <message>
        <source>Yesterday</source>
        <translation>Ayer</translation>
    </message>
    <message>
        <source>Last 7 days</source>
        <translation>Últimos 7 días</translation>
    </message>
    <message>
        <source>This month</source>
        <translation>Este mes</translation>
    </message>
    <message>
        <source>Never</source>
        <translation>Nunca</translation>
    </message>
    <message>
        <source>Older than 6 months</source>
        <translation>Más de 6 meses</translation>
    </message>
</context>
<context>
    <name>FriendWidget</name>
    <message>
        <source>Invite to conference</source>
        <comment>Menu to invite a friend to a conference</comment>
        <translation>Invitar al grupo</translation>
    </message>
    <message>
        <source>To new conference</source>
        <translation>A un nuevo grupo</translation>
    </message>
    <message>
        <source>Invite to conference &apos;%1&apos;</source>
        <translation>Invitar al grupo &apos;%1&apos;</translation>
    </message>
    <message>
        <source>Move to circle...</source>
        <comment>Menu to move a friend into a different circle</comment>
        <translation>Mover al círculo...</translation>
    </message>
    <message>
        <source>To new circle</source>
        <translation>A un nuevo círculo</translation>
    </message>
    <message>
        <source>Remove from circle &apos;%1&apos;</source>
        <translation>Eliminar del círculo &quot;%1&quot;</translation>
    </message>
    <message>
        <source>Set alias...</source>
        <translation>Establecer alias...</translation>
    </message>
    <message>
        <source>Auto accept files from this friend</source>
        <comment>context menu entry</comment>
        <translation>Aceptar archivos de este amigo automáticamente</translation>
    </message>
    <message>
        <source>Show details</source>
        <translation>Mostrar detalles</translation>
    </message>
    <message>
        <source>New message</source>
        <translation>Nuevo mensaje</translation>
    </message>
    <message>
        <source>Online</source>
        <translation>Conectado</translation>
    </message>
    <message>
        <source>Away</source>
        <translation>Ausente</translation>
    </message>
    <message>
        <source>Busy</source>
        <translation>Ocupado</translation>
    </message>
    <message>
        <source>Offline</source>
        <translation>Desconectado</translation>
    </message>
    <message>
        <source>Open chat in new window</source>
        <translation>Abrir chat en una nueva ventana</translation>
    </message>
    <message>
        <source>Remove chat from this window</source>
        <translation>Quitar chat de esta ventana</translation>
    </message>
    <message>
        <source>Move to circle &quot;%1&quot;</source>
        <translation>Mover al círculo &quot;%1&quot;</translation>
    </message>
    <message>
        <source>Remove friend</source>
        <comment>Menu to remove the friend from the friend list</comment>
        <translation>Suprimir amigo</translation>
    </message>
    <message>
        <source>Blocked</source>
        <translation>Bloqueado</translation>
    </message>
</context>
<context>
    <name>GeneralForm</name>
    <message>
        <source>General</source>
        <translation>General</translation>
    </message>
    <message>
        <source>%1 (no fonts)</source>
        <translation>%1 (no hay fuentes)</translation>
    </message>
    <message>
        <source>Auto select</source>
        <translatorcomment>Automated translation.</translatorcomment>
        <translation>Selección automática</translation>
    </message>
</context>
<context>
    <name>GeneralSettings</name>
    <message>
        <source>General Settings</source>
        <translation>Opciones generales</translation>
    </message>
    <message>
        <source>The translation may not load until qTox restarts.</source>
        <translation>Puede que necesites reiniciar qTox para activar la traducción.</translation>
    </message>
    <message>
        <source>Start in tray</source>
        <translation>Iniciar en la bandeja</translation>
    </message>
    <message>
        <source>Close to tray</source>
        <translation>Cerrar a la bandeja</translation>
    </message>
    <message>
        <source>Minimize to tray</source>
        <translation>Minimizar a la bandeja</translation>
    </message>
    <message>
        <source>Show contacts&apos; status changes</source>
        <translation>Mostrar cambios de estado de amigos</translation>
    </message>
    <message>
        <source>Auto away after (0 to disable):</source>
        <translation>Ausente después de (0 para desactivar):</translation>
    </message>
    <message>
        <source>Set to 0 to disable</source>
        <translation>0 para desactivar</translation>
    </message>
    <message>
        <source>Language:</source>
        <translation>Idioma:</translation>
    </message>
    <message>
        <source>Enable light tray icon.</source>
        <comment>toolTip for light icon setting</comment>
        <translation>Habilitará un ícono claro en la bandeja.</translation>
    </message>
    <message>
        <source>Light icon</source>
        <translation>Ícono claro</translation>
    </message>
    <message>
        <source>qTox will start minimized in tray.</source>
        <comment>toolTip for Start in tray setting</comment>
        <translation>qTox se iniciará minimizado en la bandeja.</translation>
    </message>
    <message>
        <source>Autostart</source>
        <translation>Iniciar automáticamente</translation>
    </message>
    <message>
        <source>Set where files will be saved.</source>
        <translation>Establece dónde se guardarán los archivos.</translation>
    </message>
    <message>
        <source>Your status is changed to Away after set period of inactivity.</source>
        <translation>Tu estado cambia a &apos;Ausente&apos; después del período de inactividad establecido.</translation>
    </message>
    <message>
        <source>Start qTox on operating system startup (current profile).</source>
        <translation>Iniciar qTox (usando el perfil actual) junto con el sistema operativo.</translation>
    </message>
    <message>
        <source>Show system tray icon</source>
        <translation>Mostrar ícono en la bandeja</translation>
    </message>
    <message>
        <source>Autoaccept files</source>
        <translation>Aceptar archivos automáticamente</translation>
    </message>
    <message>
        <source>Default directory to save files:</source>
        <translation>Directorio predeterminado para guardar archivos:</translation>
    </message>
    <message>
        <source>Check for updates</source>
        <translation>Verificar actualizaciones</translation>
    </message>
    <message>
        <source>Spell checking</source>
        <translation>Corrección ortográfica</translation>
    </message>
    <message>
        <source>Max autoaccept file size (0 to disable):</source>
        <translation>Tamaño máximo de archivo con aceptación automática (0 para deshabilitar):</translation>
    </message>
    <message>
        <source> MB</source>
        <translation> MB</translation>
    </message>
    <message>
        <source>After pressing minimize (_) qTox will minimize to tray,
instead of system taskbar.</source>
        <comment>toolTip for minimize to tray setting</comment>
        <translation>Después de presionar a minimizar (_) qTox minimizará a la bandeja,
en lugar de la barra de tareas del sistema.</translation>
    </message>
    <message>
        <source>After pressing close (X) qTox will close to tray,
instead of closing entirely.</source>
        <comment>toolTip for close to tray setting</comment>
        <translation>Después de presionar cerrar (X) qTox minimizará a la bandeja,
en lugar de cerrarse por completo.</translation>
    </message>
    <message>
        <source>You can set this on a per-friend basis by right clicking individual friends.</source>
        <comment>autoaccept cb tooltip</comment>
        <translation>Se puede configurar de forma personalizada con clic derecho sobre el amigo.</translation>
    </message>
    <message>
        <source>Add a chat message when a user joins or leaves a conference</source>
        <translation>Añadir un mensaje de conversación cuando un usuario se une o abandona un grupo</translation>
    </message>
    <message>
        <source>Click here if you find errors in a translation and would like to help fix it.</source>
        <translation>Haga clic aquí si encuentra errores en una traducción y le gustaría ayudar a solucionarlo.</translation>
    </message>
    <message>
        <source>Help translate</source>
        <translation>Ayuda a traducir</translation>
    </message>
    <message>
        <source> min</source>
        <translation> min</translation>
    </message>
</context>
<context>
    <name>GenericChatForm</name>
    <message>
        <source>Send message</source>
        <translation>Enviar mensaje</translation>
    </message>
    <message>
        <source>Smileys</source>
        <translation>Emoticonos</translation>
    </message>
    <message>
        <source>Send file(s)</source>
        <translation>Enviar archivo(s)</translation>
    </message>
    <message>
        <source>Send a screenshot</source>
        <translation>Enviar captura de pantalla</translation>
    </message>
    <message>
        <source>Save chat log</source>
        <translation>Guardar historial de chat</translation>
    </message>
    <message>
        <source>Clear displayed messages</source>
        <translation>Borrar mensajes actuales</translation>
    </message>
    <message>
        <source>Quote selected text</source>
        <translation>Citar texto seleccionado</translation>
    </message>
    <message>
        <source>Copy link address</source>
        <translation>Copiar la dirección del enlace</translation>
    </message>
    <message>
        <source>Confirmation</source>
        <translation>Confirmación</translation>
    </message>
    <message>
        <source>Search in text</source>
        <translation>Buscar en el texto</translation>
    </message>
    <message>
        <source>Go to current date</source>
        <translation>Ir a la fecha actual</translation>
    </message>
    <message>
        <source>Load chat history...</source>
        <translation>Cargar historial de chat...</translation>
    </message>
    <message>
        <source>Export to file</source>
        <translation>Exportar a fichero</translation>
    </message>
    <message>
        <source>Are you sure that you want to clear all displayed messages?</source>
        <translation>¿Estás seguro de que desea borrar todos los mensajes mostrados?</translation>
    </message>
</context>
<context>
    <name>IdentitySettings</name>
    <message>
        <source>Public Information</source>
        <translation>Información pública</translation>
    </message>
    <message>
        <source>Tox ID</source>
        <translation>ID de Tox</translation>
    </message>
    <message>
        <source>Your Tox ID (click to copy)</source>
        <translation>Tu ID de Tox (haz clic para copiarla)</translation>
    </message>
    <message>
        <source>Profile</source>
        <translation>Perfil</translation>
    </message>
    <message>
        <source>Rename profile.</source>
        <comment>tooltip for renaming profile button</comment>
        <translation>Aquí puedes renombrar tu perfil actual.</translation>
    </message>
    <message>
        <source>Delete profile.</source>
        <comment>delete profile button tooltip</comment>
        <translation>Eliminará tu perfil actual.</translation>
    </message>
    <message>
        <source>Go back to the login screen</source>
        <comment>tooltip for logout button</comment>
        <translation>Volver a la pantalla de inicio de sesión</translation>
    </message>
    <message>
        <source>Logout</source>
        <comment>import profile button</comment>
        <translation>Cerrar sesión</translation>
    </message>
    <message>
        <source>Remove password</source>
        <translation>Eliminar contraseña</translation>
    </message>
    <message>
        <source>Change password</source>
        <translation>Cambiar contraseña</translation>
    </message>
    <message>
        <source>This QR code contains your Tox ID. You may share this with your friends as well.</source>
        <translation>Este código QR contiene tu ID de Tox. Puedes compartirlo con tus amigos.</translation>
    </message>
    <message>
        <source>Save image</source>
        <translation>Guardar imagen</translation>
    </message>
    <message>
        <source>Copy image</source>
        <translation>Copiar imagen</translation>
    </message>
    <message>
        <source>Rename</source>
        <comment>rename profile button</comment>
        <translation>Renombrar</translation>
    </message>
    <message>
        <source>Export</source>
        <comment>export profile button</comment>
        <translation>Exportar</translation>
    </message>
    <message>
        <source>Allows you to export your Tox profile to a file.
Profile does not contain your history.</source>
        <comment>tooltip for profile exporting button</comment>
        <translation>Te permite exportar tu perfil Tox a un archivo.
El perfil no contiene tu historial.</translation>
    </message>
    <message>
        <source>Delete</source>
        <comment>delete profile button</comment>
        <translation>Eliminar</translation>
    </message>
    <message>
        <source>Remove your password and encryption from your profile.</source>
        <comment>Tooltip for the `Remove password` button.</comment>
        <translation>Eliminar tu contraseña y cifrado de tu perfil.</translation>
    </message>
    <message>
        <source>Name input</source>
        <translation>Introducir nombre</translation>
    </message>
    <message>
        <source>Name visible to contacts</source>
        <translation>Nombre visible para los contactos</translation>
    </message>
    <message>
        <source>Status message input</source>
        <translation>Introducir mensaje de estado</translation>
    </message>
    <message>
        <source>Your Tox ID</source>
        <translation>Tu ID de Tox</translation>
    </message>
    <message>
        <source>Save QR image as file</source>
        <translation>Guardar la imagen QR como un archivo</translation>
    </message>
    <message>
        <source>Copy QR image to clipboard</source>
        <translation>Copiar la imagen QR en el portapapeles del sistema</translation>
    </message>
    <message>
        <source>Rename profile.</source>
        <translation>Renombrar perfil.</translation>
    </message>
    <message>
        <source>Delete profile.</source>
        <translation>Elimina perfil.</translation>
    </message>
    <message>
        <source>Export profile</source>
        <translation>Exportar perfil</translation>
    </message>
    <message>
        <source>Remove password from profile</source>
        <translation>Eliminar contraseña del perfil</translation>
    </message>
    <message>
        <source>Change profile password</source>
        <translation>Cambiar la contraseña del perfil</translation>
    </message>
    <message>
        <source>My name:</source>
        <translation>Mi nombre:</translation>
    </message>
    <message>
        <source>My status:</source>
        <translation>Mi estado:</translation>
    </message>
    <message>
        <source>My profile</source>
        <translation>Mi perfil</translation>
    </message>
    <message>
        <source>This ID allows other Tox users to add and contact you.
Share it with your friends to begin chatting.</source>
        <comment>Tox ID tooltip</comment>
        <translation>Este ID permite a otros usuarios de Tox añadirte y ponerse en contacto contigo.
Compártela con tus amigos para empezar a chatear.</translation>
    </message>
    <message>
        <source>Set your status message that will be shown to others</source>
        <translation>Establezca su mensaje de estado que se mostrará a los demás</translation>
    </message>
</context>
<context>
    <name>LoadHistoryDialog</name>
    <message>
        <source>Load history dialog</source>
        <translation>Cargar historial</translation>
    </message>
    <message>
        <source>Load history from:</source>
        <translation>Cargar historial desde:</translation>
    </message>
</context>
<context>
    <name>LoginScreen</name>
    <message>
        <source>Username:</source>
        <translation>Usuario:</translation>
    </message>
    <message>
        <source>Password:</source>
        <translation>Contraseña:</translation>
    </message>
    <message>
        <source>Confirm:</source>
        <translation>Confirmar:</translation>
    </message>
    <message>
        <source>Password strength: %p%</source>
        <translation>Robustez de la contraseña: %p%</translation>
    </message>
    <message>
        <source>Create Profile</source>
        <translation>Crear perfil</translation>
    </message>
    <message>
        <source>If the profile does not have a password, qTox can skip the login screen</source>
        <translation>Si el perfil no está protegido con contraseña, qTox puede saltarse la pantalla de inicio de sesión</translation>
    </message>
    <message>
        <source>Load automatically</source>
        <translation>Iniciar sesión automáticamente</translation>
    </message>
    <message>
        <source>Load</source>
        <translation>Iniciar</translation>
    </message>
    <message>
        <source>Load Profile</source>
        <translation>Cargar perfil</translation>
    </message>
    <message>
        <source>New Profile</source>
        <translation>Nuevo perfil</translation>
    </message>
    <message>
        <source>Couldn&apos;t create a new profile</source>
        <translation>No se pudo crear un nuevo perfil</translation>
    </message>
    <message>
        <source>The username must not be empty.</source>
        <translation>El nombre de usuario no puede estar vacío.</translation>
    </message>
    <message>
        <source>The password must be at least 6 characters long.</source>
        <translation>La contraseña tiene que tener al menos 6 caracteres.</translation>
    </message>
    <message>
        <source>A profile with this name already exists.</source>
        <translation>Ya existe un perfil con ese nombre.</translation>
    </message>
    <message>
        <source>Couldn&apos;t load this profile</source>
        <translation>No se pudo cargar el perfil</translation>
    </message>
    <message>
        <source>This profile is already in use.</source>
        <translation>Ese perfil ya está en uso.</translation>
    </message>
    <message>
        <source>Wrong password.</source>
        <translation>Contraseña incorrecta.</translation>
    </message>
    <message>
        <source>There is no selected profile.

You may want to create one.</source>
        <translation>No has seleccionado ningún perfil.

Tal vez quieras crear uno.</translation>
    </message>
    <message>
        <source>Import</source>
        <translation>Importar</translation>
    </message>
    <message>
        <source>Password protected profiles can&apos;t be automatically loaded.</source>
        <translation>Perfiles protegidos con contraseña no pueden ser cargados automáticamente.</translation>
    </message>
    <message>
        <source>Username input field</source>
        <translation>Campo para introducir el nombre del usuario</translation>
    </message>
    <message>
        <source>Password input field, you can leave it empty (no password), or type at least 6 characters</source>
        <translation>Campo de entrada de la contraseña, puedes dejarlo vacío (sin contraseña), o escribir al menos 6 caracteres</translation>
    </message>
    <message>
        <source>Password confirmation field</source>
        <translation>Campo de confirmación de contraseña</translation>
    </message>
    <message>
        <source>Create a new profile button</source>
        <translation>Botón para crear un perfil nuevo</translation>
    </message>
    <message>
        <source>Profile list</source>
        <translation>Lista de perfiles</translation>
    </message>
    <message>
        <source>List of profiles</source>
        <translation>Lista de perfiles</translation>
    </message>
    <message>
        <source>Password input</source>
        <translation>Introducir contraseña</translation>
    </message>
    <message>
        <source>Load automatically checkbox</source>
        <translation>Cargar automáticamente casilla de selección</translation>
    </message>
    <message>
        <source>Import profile</source>
        <translation>Importar perfil</translation>
    </message>
    <message>
        <source>Load selected profile button</source>
        <translation>Botón para cargar perfil seleccionado</translation>
    </message>
    <message>
        <source>New profile creation page</source>
        <translation>Nueva página de creación de perfil</translation>
    </message>
    <message>
        <source>Loading existing profile page</source>
        <translation>Cargando página de perfil existente</translation>
    </message>
    <message>
        <source>The passwords you&apos;ve entered are different.
Please make sure to enter the same password twice.</source>
        <translation>Las contraseñas ingresadas no coinciden.
Verifica que sean la misma en ambos recuadros.</translation>
    </message>
    <message>
        <source>This optional password is used to encrypt local message data and your profile.
If you lose this password, there is no way to recover it.
Press Shift+F1 for more information.</source>
        <translation>Esta contraseña opcional se utiliza para cifrar los datos de los mensajes locales y su perfil.
Si pierde esta contraseña, no hay forma de recuperarla.
Presione Mayús+F1 para obtener más información.</translation>
    </message>
    <message>
        <source>The password you enter here is optional and encrypts message data and your Tox secret key. It does not encrypt files received. Your profile data is never sent to any servers. This is not a remote login, it&apos;s local to your computer only. qTox developers won&apos;t be able to recover your password if lost.</source>
        <translation>La contraseña que ingresa aquí es opcional y cifra los datos del mensaje y su clave secreta Tox. No cifra los archivos recibidos. Los datos de su perfil nunca se envían a ningún servidor. Este no es un inicio de sesión remoto, es local únicamente en su computadora. Los desarrolladores de qTox no podrán recuperar su contraseña si la pierde.</translation>
    </message>
    <message>
        <source>Password input field, minimum 6 characters long</source>
        <translation>Campo para introducir contraseña, con una longitud mínima de 6 caracteres</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <source>Create a conference</source>
        <translation>Crear un grupo</translation>
    </message>
    <message>
        <source>View completed file transfers</source>
        <translation>Ver transferencias de archivos completadas</translation>
    </message>
    <message>
        <source>Change your settings</source>
        <translation>Configurar</translation>
    </message>
    <message>
        <source>Close</source>
        <translation>Cerrar</translation>
    </message>
    <message>
        <source>Your name</source>
        <translation>Tu nombre</translation>
    </message>
    <message>
        <source>Your status</source>
        <translation>Tu estado</translation>
    </message>
    <message>
        <source>Open profile</source>
        <translation>Abrir perfil</translation>
    </message>
    <message>
        <source>Open profile page when clicked</source>
        <translation>Abrir página de perfil al hacer clic</translation>
    </message>
    <message>
        <source>Status message input</source>
        <translation>Introducir mensaje de estado</translation>
    </message>
    <message>
        <source>Set your status message that will be shown to others</source>
        <translation>Establezca su mensaje de estado que se mostrará a los demás</translation>
    </message>
    <message>
        <source>Status</source>
        <translation>Estado</translation>
    </message>
    <message>
        <source>Set availability status</source>
        <translation>Establecer estado de disponibilidad</translation>
    </message>
    <message>
        <source>Contact search</source>
        <translation>Buscar contacto</translation>
    </message>
    <message>
        <source>Contact search input for known friends</source>
        <translation>Buscar contactos para amigos conocidos</translation>
    </message>
    <message>
        <source>Sorting and visibility</source>
        <translation>Clasificación y visibilidad</translation>
    </message>
    <message>
        <source>Set friends sorting and visibility</source>
        <translation>Establecer clasificación y visibilidad de tus amigos</translation>
    </message>
    <message>
        <source>Open Add friends page</source>
        <translation>Abrir página de amigos agregados</translation>
    </message>
    <message>
        <source>Conference</source>
        <translation>Grupo</translation>
    </message>
    <message>
        <source>Open conference management page</source>
        <translation>Abrir página de gestión de grupo</translation>
    </message>
    <message>
        <source>File transfers history</source>
        <translation>Historial de transferencias de archivos</translation>
    </message>
    <message>
        <source>Open File transfers history</source>
        <translation>Abrir historial de transferencias de archivos</translation>
    </message>
    <message>
        <source>Settings</source>
        <translation>Opciones</translation>
    </message>
    <message>
        <source>Open Settings</source>
        <translation>Abrir opciones</translation>
    </message>
    <message>
        <source>Open internal debugging tools</source>
        <translation>Abrir herramientas de depuración internas</translation>
    </message>
    <message>
        <source>Debug</source>
        <translation>Depurar</translation>
    </message>
    <message>
        <source>Open Debugger</source>
        <translation>Abrir depurador</translation>
    </message>
    <message>
        <source>Add friend</source>
        <translation>Agregar amigo</translation>
    </message>
</context>
<context>
    <name>MessageBoxManager</name>
    <message>
        <source>Executable file</source>
        <comment>popup title</comment>
        <translation>Archivo ejecutable</translation>
    </message>
    <message>
        <source>You have asked qTox to open an executable file. Executable files can potentially damage your computer. Are you sure want to open this file?</source>
        <comment>popup text</comment>
        <translation>Has seleccionado que qTox abra un archivo ejecutable. Los archivos ejecutables pueden ser dañinos para tu computador. ¿Estás seguro de que quieres abrirlo?</translation>
    </message>
</context>
<context>
    <name>NetCamView</name>
    <message>
        <source>Tox video</source>
        <translation>Vídeo Tox</translation>
    </message>
    <message>
        <source>Full Screen</source>
        <translation>Pantalla completa</translation>
    </message>
    <message>
        <source>Toggle video preview</source>
        <translation>Exhibir vista previa de vídeo</translation>
    </message>
    <message>
        <source>Mute audio</source>
        <translation>Silenciar el audio</translation>
    </message>
    <message>
        <source>Mute microphone</source>
        <translation>Silenciar micrófono</translation>
    </message>
    <message>
        <source>End video call</source>
        <translation>Terminar videollamada</translation>
    </message>
    <message>
        <source>Exit full screen</source>
        <translation>Salir de pantalla completa</translation>
    </message>
    <message>
        <source>Hide messages</source>
        <translation>Ocultar mensajes</translation>
    </message>
    <message>
        <source>Show messages</source>
        <translation>Mostrar mensajes</translation>
    </message>
</context>
<context>
    <name>Nexus</name>
    <message>
        <source>View</source>
        <comment>macOS Menu bar</comment>
        <translation>Ver</translation>
    </message>
    <message>
        <source>Window</source>
        <comment>macOS Menu bar</comment>
        <translation>Ventana</translation>
    </message>
    <message>
        <source>Minimize</source>
        <comment>macOS Menu bar</comment>
        <translation>Minimizar</translation>
    </message>
    <message>
        <source>Bring All to Front</source>
        <comment>macOS Menu bar</comment>
        <translation>Traer todos al frente</translation>
    </message>
    <message>
        <source>Exit Full Screen</source>
        <translation>Salir de pantalla completa</translation>
    </message>
    <message>
        <source>Enter Full Screen</source>
        <translation>Pantalla completa</translation>
    </message>
</context>
<context>
    <name>NotificationEdgeWidget</name>
    <message numerus="yes">
        <source>Unread message(s)</source>
        <translation>
            <numerusform>Mensaje no leído</numerusform>
            <numerusform>Mensajes no leídos</numerusform>
        </translation>
    </message>
</context>
<context>
    <name>NotificationGenerator</name>
    <message>
        <source>New message</source>
        <translation>Nuevo mensaje</translation>
    </message>
    <message>
        <source>New conference message</source>
        <translation>Nuevo mensaje de grupo</translation>
    </message>
    <message>
        <source>Incoming file transfer</source>
        <translation>Recibiendo transferencia de archivo</translation>
    </message>
    <message>
        <source>%1 - file transfer</source>
        <extracomment>e.g. Bob - file transfer</extracomment>
        <translation>%1 - transferencia de archivo</translation>
    </message>
    <message>
        <source>Conference invite received</source>
        <translation>Invitación de grupo recibida</translation>
    </message>
    <message>
        <source>%1 invites you to join a conference.</source>
        <translation>%1 te invita a unirte a un grupo.</translation>
    </message>
    <message>
        <source>Friend request received</source>
        <translation>Solicitud de amistad recibida</translation>
    </message>
    <message>
        <source>Friend request received from %1</source>
        <translation>Solicitud de amistad recibida de%1</translation>
    </message>
    <message>
        <source>Incoming call</source>
        <translation>Llamada entrante</translation>
    </message>
</context>
<context>
    <name>PasswordEdit</name>
    <message>
        <source>Caps-lock enabled</source>
        <translation>BLOQUEO DE MAYÚSCULAS ACTIVADO</translation>
    </message>
</context>
<context>
    <name>PrivacyForm</name>
    <message>
        <source>Privacy</source>
        <translation>Privacidad</translation>
    </message>
    <message>
        <source>Confirmation</source>
        <translation>Confirmación</translation>
    </message>
    <message>
        <source>Do you want to permanently delete all chat history?</source>
        <translation>¿Deseas eliminar permanentemente el historial del chat?</translation>
    </message>
</context>
<context>
    <name>PrivacySettings</name>
    <message>
        <source>Your friends will be able to see when you are typing.</source>
        <comment>tooltip for typing notifications setting</comment>
        <translation>Tus amigos podrán ver cuándo estás escribiendo.</translation>
    </message>
    <message>
        <source>Send typing notifications</source>
        <translation>Enviar notificaciones de tecleo</translation>
    </message>
    <message>
        <source>Keep chat history</source>
        <translation>Guardar historial del chat</translation>
    </message>
    <message>
        <source>NoSpam is part of your Tox ID.
If you are being spammed with friend requests, you should change your NoSpam.
People will be unable to add you with your old ID, but you will keep your current friends.</source>
        <comment>toolTip for nospam</comment>
        <translation>NoSpam es parte de tu ID de Tox.
Si estás recibiendo solicitudes de amistad no deseadas, considera cambiar tu NoSpam.
Ya no va a ser posible que te agreguen con tu vieja ID, pero no vas a perder a los amigos que ya hayas agregado.</translation>
    </message>
    <message>
        <source>NoSpam</source>
        <translation>Anti-spam</translation>
    </message>
    <message>
        <source>NoSpam is a part of your ID that can be changed at will.
If you are getting spammed with friend requests, change the NoSpam.</source>
        <translation>NoSpam es una parte de tu ID de Tox que puedes cambiar cuando desees.
Si estás recibiendo solicitudes de amistad no deseadas, cambia tu NoSpam.</translation>
    </message>
    <message>
        <source>Generate random NoSpam</source>
        <translation>Generar NoSpam aleatorio</translation>
    </message>
    <message>
        <source>Chat history keeping is still in development.
Save format changes are possible, which may result in data loss.</source>
        <comment>toolTip for Keep History setting</comment>
        <translation>Mantener un historial de chat es una función aún en desarrollo.
Es posible que haya cambios en el formato de guardado, lo que puede generar una pérdida de datos.</translation>
    </message>
    <message>
        <source>Privacy</source>
        <translation>Privacidad</translation>
    </message>
    <message>
        <source>Conference block list</source>
        <translation>Lista negra</translation>
    </message>
    <message>
        <source>Filter out conference messages by conference members&apos; public keys. Put public keys here, one per line.</source>
        <translation>Filtrar mensajes de grupo por clave pública de miembros del grupo. Ponga la clave pública aquí, una por línea.</translation>
    </message>
</context>
<context>
    <name>Profile</name>
    <message>
        <source>Failed to derive key from password, the profile won&apos;t use the new password.</source>
        <translation>Error al derivar la clave de la contraseña, el perfil no usará la nueva contraseña.</translation>
    </message>
    <message>
        <source>Toxing on qTox</source>
        <translation>Toxeando con qTox</translation>
    </message>
    <message>
        <source>Couldn&apos;t change database password, it may be corrupted or use the old password.</source>
        <translation>No se pudo cambiar la contraseña de la base de datos, puede estar dañada o usar la contraseña anterior.</translation>
    </message>
</context>
<context>
    <name>ProfileForm</name>
    <message>
        <source>Current profile: </source>
        <translation>Perfil actual: </translation>
    </message>
    <message>
        <source>Choose a profile picture</source>
        <translation>Elige una imagen de perfil</translation>
    </message>
    <message>
        <source>Error</source>
        <translation>Error</translation>
    </message>
    <message>
        <source>Unable to open this file.</source>
        <translation>No fue posible abrir el archivo.</translation>
    </message>
    <message>
        <source>Unable to read this image.</source>
        <translation>No fue posible leer la imagen.</translation>
    </message>
    <message>
        <source>The supplied image is too large.
Please use another image.</source>
        <translation>La imagen seleccionada es demasiado grande.
Por favor usa otra.</translation>
    </message>
    <message>
        <source>Rename &quot;%1&quot;</source>
        <comment>renaming a profile</comment>
        <translation>Renombrar &quot;%1&quot;</translation>
    </message>
    <message>
        <source>Couldn&apos;t rename the profile to &quot;%1&quot;</source>
        <translation>No se pudo renombrar el perfil a &quot;%1&quot;</translation>
    </message>
    <message>
        <source>Nothing to remove</source>
        <translation>Nada que eliminar</translation>
    </message>
    <message>
        <source>Your profile does not have a password!</source>
        <translation>¡Tu perfil no tiene contraseña!</translation>
    </message>
    <message>
        <source>Please enter a new password.</source>
        <translation>Ingresa tu nueva contraseña.</translation>
    </message>
    <message>
        <source>Are you sure you want to delete this profile?</source>
        <comment>deletion confirmation text</comment>
        <translation>¿Estás seguro de que deseas eliminar este perfil?</translation>
    </message>
    <message>
        <source>Save</source>
        <comment>save qr image</comment>
        <translation>Guardar</translation>
    </message>
    <message>
        <source>Save QrCode (*.png)</source>
        <comment>save dialog filter</comment>
        <translation>Guardar código QR (*.png)</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Eliminar</translation>
    </message>
    <message>
        <source>Files could not be deleted!</source>
        <comment>deletion failed title</comment>
        <translation>¡No se pudieron eliminar los archivos!</translation>
    </message>
    <message>
        <source>Change password</source>
        <comment>button text</comment>
        <translation>Cambiar contraseña</translation>
    </message>
    <message>
        <source>Set profile password</source>
        <comment>button text</comment>
        <translation>Establecer contraseña del perfil</translation>
    </message>
    <message>
        <source>Current profile location: %1</source>
        <translation>Ubicación del perfil actual: %1</translation>
    </message>
    <message>
        <source>Couldn&apos;t change password</source>
        <translation>No se pudo cambiar la contraseña</translation>
    </message>
    <message>
        <source>Empty path is unavailable</source>
        <translation>Ruta vacía no está disponible</translation>
    </message>
    <message>
        <source>Failed to rename</source>
        <translation>Error al renombrar</translation>
    </message>
    <message>
        <source>Profile already exists</source>
        <translation>Perfil ya existe</translation>
    </message>
    <message>
        <source>A profile named &quot;%1&quot; already exists.</source>
        <translation>Un perfil llamado &quot;%1&quot; ya existe.</translation>
    </message>
    <message>
        <source>Empty name</source>
        <translation>Nombre vacío</translation>
    </message>
    <message>
        <source>Empty name is unavailable</source>
        <translation>Nombre vacío no está disponible</translation>
    </message>
    <message>
        <source>Empty path</source>
        <translation>Ruta vacía</translation>
    </message>
    <message>
        <source>Export profile</source>
        <extracomment>save dialog title</extracomment>
        <translation>Exportar perfil</translation>
    </message>
    <message>
        <source>Tox save file (*.tox)</source>
        <extracomment>save dialog filter</extracomment>
        <translation>Guardar archivo Tox (*.tox)</translation>
    </message>
    <message>
        <source>The following files could not be deleted:</source>
        <extracomment>deletion failed text part 1</extracomment>
        <translation>Los siguientes archivos no pudieron ser eliminados:</translation>
    </message>
    <message>
        <source>Please manually remove them.</source>
        <extracomment>deletion failed text part 2</extracomment>
        <translation>Por favor eliminar manualmente.</translation>
    </message>
    <message>
        <source>Images (%1)</source>
        <comment>filetype filter</comment>
        <translation>Imágenes (%1)</translation>
    </message>
    <message>
        <source>Failed to save file</source>
        <translation>Error al guardar el archivo</translation>
    </message>
    <message>
        <source>The file you chose could not be saved.</source>
        <translation>No se ha podido guardar el archivo elegido.</translation>
    </message>
    <message>
        <source>Empty path is unavailable.</source>
        <translation>No es posible escoger directorios en blanco.</translation>
    </message>
    <message>
        <source>Couldn&apos;t change database password, it may be corrupted or use the old password.</source>
        <translation>No se pudo cambiar la contraseña de la base de datos, puede estar dañada o usar la contraseña anterior.</translation>
    </message>
    <message>
        <source>Tox user names cannot exceed %1 characters.</source>
        <translation>Los nombres de usuario de Tox no pueden superar los %1 caracteres.</translation>
    </message>
    <message>
        <source>Delete profile</source>
        <comment>deletion confirmation title</comment>
        <translation>Borrar perfil</translation>
    </message>
    <message>
        <source>Remove password</source>
        <comment>deletion confirmation title</comment>
        <translation>Eliminar contraseña</translation>
    </message>
    <message>
        <source>Are you sure you want to remove your password?</source>
        <extracomment>deletion confirmation text</extracomment>
        <translation>¿Estás seguro de que quieres eliminar tu contraseña?</translation>
    </message>
    <message>
        <source>This ID allows other Tox users to add and contact you.
Share it with your friends to begin chatting.

This ID includes the NoSpam code (in blue), and the checksum (in gray).</source>
        <translation>Este ID permite a otros usuarios de Tox añadirte y ponerse en contacto contigo.
Compártela con tus amigos para empezar a chatear.

Este ID incluye el código NoSpam (en azul), y la suma de comprobación (en gris).</translation>
    </message>
</context>
<context>
    <name>ProfileImporter</name>
    <message>
        <source>Import profile</source>
        <comment>import dialog title</comment>
        <translation>Importar perfil</translation>
    </message>
    <message>
        <source>Tox save file (*.tox)</source>
        <comment>import dialog filter</comment>
        <translation>Archivo Tox (*.tox)</translation>
    </message>
    <message>
        <source>Ignoring non-Tox file</source>
        <comment>popup title</comment>
        <translation>Ignorando archivo no Tox</translation>
    </message>
    <message>
        <source>Warning: You have chosen a file that is not a Tox save file; ignoring.</source>
        <comment>popup text</comment>
        <translation>Advertencia: el archivo Tox seleccionado es inválido y ha sido ignorado.</translation>
    </message>
    <message>
        <source>Profile already exists</source>
        <comment>import confirm title</comment>
        <translation>Perfil ya existe</translation>
    </message>
    <message>
        <source>A profile named &quot;%1&quot; already exists. Do you want to erase it?</source>
        <comment>import confirm text</comment>
        <translation>Un perfil llamado &quot;%1&quot; ya existe. ¿Deseas eliminarlo?</translation>
    </message>
    <message>
        <source>File doesn&apos;t exist</source>
        <translation>Archivo no existe</translation>
    </message>
    <message>
        <source>Profile doesn&apos;t exist</source>
        <translation>El perfil no existe</translation>
    </message>
    <message>
        <source>Profile imported</source>
        <translation>Perfil importado</translation>
    </message>
    <message>
        <source>%1.tox was successfully imported</source>
        <translation>%1.tox ha sido importado exitosamente</translation>
    </message>
</context>
<context>
    <name>QApplication</name>
    <message>
        <source>Ok</source>
        <translation>Aceptar</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
    <message>
        <source>Yes</source>
        <translation>Sí</translation>
    </message>
    <message>
        <source>No</source>
        <translation>No</translation>
    </message>
    <message>
        <source>LTR</source>
        <comment>DO NOT TRANSLATE. Instead, set this string to &apos;RTL&apos; in right-to-left languages (for example Hebrew and Arabic) to get proper widget layout. This string should only ever be &apos;LTR&apos; or &apos;RTL&apos;.</comment>
        <translation>LTR</translation>
    </message>
</context>
<context>
    <name>QFileDialog</name>
    <message>
        <source>Choose an auto-accept directory</source>
        <comment>popup title</comment>
        <translation>Elige un directorio para descargas automáticas</translation>
    </message>
</context>
<context>
    <name>QMessageBox</name>
    <message>
        <source>Couldn&apos;t add friend</source>
        <translation>No se pudo agregar el amigo</translation>
    </message>
    <message>
        <source>You can&apos;t add yourself as a friend!</source>
        <comment>When trying to add your own Tox ID as friend</comment>
        <translation>¡No puedes agregarte a ti como amigo!</translation>
    </message>
    <message>
        <source>%1 is not a valid Tox address.</source>
        <translation>%1 no es una dirección Tox válida.</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <source>Default</source>
        <translation>Predeterminado</translation>
    </message>
    <message>
        <source>Blue</source>
        <translation>Azul</translation>
    </message>
    <message>
        <source>Olive</source>
        <translation>Oliva</translation>
    </message>
    <message>
        <source>Red</source>
        <translation>Rojo</translation>
    </message>
    <message>
        <source>Violet</source>
        <translation>Violeta</translation>
    </message>
    <message>
        <source>Incoming call...</source>
        <translation>Llamada entrante...</translation>
    </message>
    <message>
        <source>%1 here! Tox me maybe?</source>
        <comment>Default message in Tox URI friend requests. Write something appropriate!</comment>
        <translation>¡Hola, soy %1! ¿Deseas agregarme en Tox?</translation>
    </message>
    <message>
        <source>None</source>
        <comment>No camera device set</comment>
        <translation>Ninguno</translation>
    </message>
    <message>
        <source>Desktop</source>
        <comment>Desktop as a camera input for screen sharing</comment>
        <translation>Pantalla</translation>
    </message>
    <message>
        <source>Error</source>
        <translation>Error</translation>
    </message>
    <message>
        <source>qTox couldn&apos;t open your chat logs, they will be disabled.</source>
        <translation>qTox no pudo abrir tus historiales de chat, serán deshabilitados.</translation>
    </message>
    <message>
        <source>Dark</source>
        <translation>Oscuro</translation>
    </message>
    <message>
        <source>Dark blue</source>
        <translation>Azul oscuro</translation>
    </message>
    <message>
        <source>Dark olive</source>
        <translation>Verde oscuro</translation>
    </message>
    <message>
        <source>Dark red</source>
        <translation>Rojo oscuro</translation>
    </message>
    <message>
        <source>Dark violet</source>
        <translation>Morado</translation>
    </message>
    <message>
        <source>online</source>
        <comment>contact status</comment>
        <translation>conectado</translation>
    </message>
    <message>
        <source>away</source>
        <comment>contact status</comment>
        <translation>ausente</translation>
    </message>
    <message>
        <source>busy</source>
        <comment>contact status</comment>
        <translation>ocupado</translation>
    </message>
    <message>
        <source>offline</source>
        <comment>contact status</comment>
        <translation>desconectado</translation>
    </message>
    <message>
        <source>blocked</source>
        <comment>contact status</comment>
        <translation>bloqueado</translation>
    </message>
    <message>
        <source>Reformatting text...</source>
        <comment>Waiting for text to be reformatted</comment>
        <translation>Reformateando el texto...</translation>
    </message>
    <message>
        <source>Failed to send file &quot;%1&quot;</source>
        <translation>No se pudo enviar el archivo &quot;%1&quot;</translation>
    </message>
    <message>
        <source>%1 has joined the conference</source>
        <translation>%1 se ha unido al grupo</translation>
    </message>
    <message>
        <source>%1 has left the conference</source>
        <translation>%1 ha abandonado el grupo</translation>
    </message>
    <message>
        <source>%1 is now known as %2</source>
        <translation>%1 ahora se llama %2</translation>
    </message>
    <message>
        <source>%1 has set the title to %2</source>
        <translation>%1 ha definido el título como %2</translation>
    </message>
    <message>
        <source>Cleared</source>
        <translation>Borradas</translation>
    </message>
    <message>
        <source>Call with %1 ended unexpectedly. %2</source>
        <translation>La llamada con %1 ha terminado inesperadamente. %2</translation>
    </message>
    <message>
        <source>Call with %1 ended. %2</source>
        <translation>Llamada con %1 terminada. %2</translation>
    </message>
    <message>
        <source>%1 is now %2</source>
        <comment>e.g. &quot;Dubslow is now online&quot;</comment>
        <translation>%1 ahora es %2</translation>
    </message>
    <message>
        <source>Calling %1</source>
        <translation>Llamando a %1</translation>
    </message>
    <message>
        <source>%1 calling</source>
        <translation>%1 llamando</translation>
    </message>
    <message>
        <source>Message failed to send</source>
        <translation>Falla en el envío del mensaje</translation>
    </message>
    <message>
        <source>%1 went offline during the call attempt</source>
        <translatorcomment>Automated translation.</translatorcomment>
        <translation>%1 se desconectó durante el intento de llamada</translation>
    </message>
    <message>
        <source>The call was terminated because %1 unexpectedly went offline. %2</source>
        <translatorcomment>Automated translation.</translatorcomment>
        <translation type="unfinished">La llamada finalizó porque %1 se desconectó inesperadamente. %2</translation>
    </message>
    <message>
        <source>Initializing</source>
        <translation>Inicializando</translation>
    </message>
    <message>
        <source>Transmitting</source>
        <translation>Transmitiendo</translation>
    </message>
    <message>
        <source>Finished</source>
        <translation>Terminado</translation>
    </message>
    <message>
        <source>Broken</source>
        <translation>Roto</translation>
    </message>
    <message>
        <source>Canceled</source>
        <translation>Cancelado</translation>
    </message>
    <message>
        <source>Paused</source>
        <translation>En pausa</translation>
    </message>
    <message>
        <source>Remote paused</source>
        <translation>Remoto pausado</translation>
    </message>
    <message>
        <source>File Name</source>
        <translation>Nombre de archivo</translation>
    </message>
    <message>
        <source>Contact</source>
        <translation>Contacto</translation>
    </message>
    <message>
        <source>Progress</source>
        <translation>Progreso</translation>
    </message>
    <message>
        <source>Size</source>
        <translation>Tamaño</translation>
    </message>
    <message>
        <source>Speed</source>
        <translation>Velocidad</translation>
    </message>
    <message>
        <source>Status</source>
        <translation>Estado</translation>
    </message>
    <message>
        <source>Control</source>
        <translation>Control</translation>
    </message>
    <message>
        <source>You have joined the conference</source>
        <translation>Te has unido al grupo</translation>
    </message>
    <message>
        <source>You have left the conference</source>
        <translation>Has abandonado el grupo</translation>
    </message>
    <message>
        <source>Failed to load chat history</source>
        <translation>Error al cargar el historial de chat</translation>
    </message>
    <message>
        <source>Database version (%1) is newer than we currently support (%2). Please upgrade qTox.</source>
        <translation>La versión de la base de datos (%1) es más reciente que la que actualmente soportamos (%2). Por favor, actualice qTox.</translation>
    </message>
</context>
<context>
    <name>RemoveChatDialog</name>
    <message>
        <source>Remove friend</source>
        <translation>Suprimir amigo</translation>
    </message>
    <message>
        <source>Remove all chat history with the friend if set</source>
        <translation>Eliminar todo el historial del chat con el amigo si está establecido</translation>
    </message>
    <message>
        <source>Also remove chat history</source>
        <translation>Eliminar también el historial del chat</translation>
    </message>
    <message>
        <source>Are you sure you want to remove %1 from your contacts list?</source>
        <translation>¿Estás seguro de que deseas eliminar a %1 de tu lista de contactos?</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Remover</translation>
    </message>
</context>
<context>
    <name>ScreenshotGrabber</name>
    <message>
        <source>Click and drag to select a region. Press %1 to hide/show qTox window, or %2 to cancel.</source>
        <comment>Help text shown when no region has been selected yet</comment>
        <translation>Cliquea y arrastra para seleccionar una región. Presiona %1 para mostar/ocultar la ventana de qTox, o %2 para cancelar.</translation>
    </message>
    <message>
        <source>Space</source>
        <comment>[Space] key on the keyboard</comment>
        <translation>Espacio</translation>
    </message>
    <message>
        <source>Escape</source>
        <comment>[Escape] key on the keyboard</comment>
        <translation>Escape</translation>
    </message>
    <message>
        <source>Press %1 to send a screenshot of the selection, %2 to hide/show qTox window, or %3 to cancel.</source>
        <comment>Help text shown when a region has been selected</comment>
        <translation>Presiona %1 para enviar una captura de pantalla de la selección, %2 para mostar/ocultar la ventana de qTox, o %3 para cancelar.</translation>
    </message>
    <message>
        <source>Enter</source>
        <comment>[Enter] key on the keyboard</comment>
        <translation>Enter</translation>
    </message>
</context>
<context>
    <name>SearchForm</name>
    <message>
        <source>The text could not be found.</source>
        <translation>Texto no encontrado.</translation>
    </message>
    <message>
        <source>Start</source>
        <translation>Iniciar</translation>
    </message>
</context>
<context>
    <name>SearchSettingsForm</name>
    <message>
        <source>Start search:</source>
        <translation>Iniciar búsqueda:</translation>
    </message>
    <message>
        <source>from the end</source>
        <translation>desde el final</translation>
    </message>
    <message>
        <source>from the beginning</source>
        <translation>desde el principio</translation>
    </message>
    <message>
        <source>after date</source>
        <translation>después de la fecha</translation>
    </message>
    <message>
        <source>before date</source>
        <translation>antes de la fecha</translation>
    </message>
    <message>
        <source>Case sensitive</source>
        <translation>Distingue mayúsculas y minúsculas</translation>
    </message>
    <message>
        <source>Whole words only</source>
        <translation>Sólo palabras enteras</translation>
    </message>
    <message>
        <source>Use regular expressions</source>
        <translation>Usar expresiones comunes</translation>
    </message>
    <message>
        <source>Select Date Dialog</source>
        <translation>Cuadro de diálogo Seleccionar fecha</translation>
    </message>
    <message>
        <source>Select a date</source>
        <translation>Seleccione una fecha</translation>
    </message>
</context>
<context>
    <name>SetPasswordDialog</name>
    <message>
        <source>The password doesn&apos;t match.</source>
        <translation>La contraseña no coincide.</translation>
    </message>
    <message>
        <source>Confirm:</source>
        <translation>Confirmar:</translation>
    </message>
    <message>
        <source>Password:</source>
        <translation>Contraseña:</translation>
    </message>
    <message>
        <source>Password strength: %p%</source>
        <translation>Robustez de la contraseña: %p%</translation>
    </message>
    <message>
        <source>Confirm password</source>
        <translation>Confirmar contraseña</translation>
    </message>
    <message>
        <source>Confirm password input</source>
        <translation>Confirmar contraseña introducida</translation>
    </message>
    <message>
        <source>Password input</source>
        <translation>Introducir contraseña</translation>
    </message>
    <message>
        <source>Password input field, minimum 6 characters long</source>
        <translation>Campo para introducir contraseña, con una longitud mínima de 6 caracteres</translation>
    </message>
    <message>
        <source>The password is too short.</source>
        <translation>La contraseña es demasiado corta.</translation>
    </message>
    <message>
        <source>Set profile password</source>
        <translation>Establecer contraseña del perfil</translation>
    </message>
</context>
<context>
    <name>Settings</name>
    <message>
        <source>Circle #%1</source>
        <translation>Círculo #%1</translation>
    </message>
    <message>
        <source>Failed to load personal settings</source>
        <translation>Fallo al cargar la configuración personal</translation>
    </message>
    <message>
        <source>Unable to upgrade settings from version %1 to version %2. Cannot start qTox.</source>
        <translation>No se puede actualizar la configuración de la versión %1 a la versión %2. No se puede iniciar qTox.</translation>
    </message>
    <message>
        <source>Failed to load global settings</source>
        <translation>Fallo al cargar las configuraciones globales</translation>
    </message>
</context>
<context>
    <name>ToxURIDialog</name>
    <message>
        <source>Do you want to add %1 as a friend?</source>
        <translation>¿Deseas agregar a %1 como amigo?</translation>
    </message>
    <message>
        <source>User ID:</source>
        <translation>ID del usuario:</translation>
    </message>
    <message>
        <source>Friend request message:</source>
        <translation>Mensaje de solicitud de amistad:</translation>
    </message>
    <message>
        <source>Send</source>
        <comment>Send a friend request</comment>
        <translation>Enviar</translation>
    </message>
    <message>
        <source>Cancel</source>
        <comment>Don&apos;t send a friend request</comment>
        <translation>Cancelar</translation>
    </message>
    <message>
        <source>Add friend</source>
        <comment>Title of the window to add a friend through Tox URI</comment>
        <translation>Agregar amigo</translation>
    </message>
</context>
<context>
    <name>UserInterfaceForm</name>
    <message>
        <source>None</source>
        <translation>Ninguno</translation>
    </message>
    <message>
        <source>User Interface</source>
        <translation>Interfaz de usuario</translation>
    </message>
</context>
<context>
    <name>UserInterfaceSettings</name>
    <message>
        <source>Chat</source>
        <translation>Chat</translation>
    </message>
    <message>
        <source>Base font:</source>
        <translation>Fuente:</translation>
    </message>
    <message>
        <source>Size: </source>
        <translation>Tamaño: </translation>
    </message>
    <message>
        <source>New text styling preference may not load on chat history until qTox restarts.
It will affect new messages immediately.

Plaintext:
    Don&apos;t apply any formatting to messages.
    E.g. &quot;**text**&quot; will show as &quot;**text**&quot;, not bold.
Show formatting characters:
    Apply formatting and show characters.
    E.g. &quot;**text**&quot; will show as &quot;**text**&quot;, bold.
Hide formatting characters:
    Apply formatting and don&apos;t show characters.
    E.g. &quot;**text**&quot; will show as &quot;text&quot;, bold.</source>
        <translation>Es posible que la nueva preferencia de estilo de texto no se cargue en el historial de chat hasta que se reinicie qTox.
Afectará a los nuevos mensajes inmediatamente.

Texto sin formato:
 No aplica ningún formato a los mensajes.
    Por ejemplo, «**texto**» se mostrará como «**texto**», sin negrita.
Mostrar caracteres de formato:
 Aplica formato y muestra los caracteres.
    Por ejemplo, «**texto**» se mostrará como «**texto**», en negrita.
Ocultar caracteres de formato:
 Aplica formato y no muestra caracteres.
    Por ejemplo, «**texto**» se mostrará como «texto», en negrita.</translation>
    </message>
    <message>
        <source>Text styling:</source>
        <translation>Estilo de formato de texto:</translation>
    </message>
    <message>
        <source>Select text styling preference.</source>
        <translation>Seleccionar el estilo en que el texto va a ser mostrado.</translation>
    </message>
    <message>
        <source>Plaintext</source>
        <translation>Texto plano</translation>
    </message>
    <message>
        <source>Show formatting characters</source>
        <translation>Mostrar caracteres de formato</translation>
    </message>
    <message>
        <source>Hide formatting characters</source>
        <translation>No mostrar caracteres de formato</translation>
    </message>
    <message>
        <source>New message</source>
        <translation>Mensaje nuevo</translation>
    </message>
    <message>
        <source>Open qTox&apos;s window when you receive a new message and no window is open yet.</source>
        <comment>tooltip for Show window setting</comment>
        <translation>Abrir una ventana de qTox al recibir un nuevo mensaje si no hay ninguna ya abierta.</translation>
    </message>
    <message>
        <source>Open window</source>
        <translation>Abrir ventana</translation>
    </message>
    <message>
        <source>Contact list</source>
        <translation>Lista de contactos</translation>
    </message>
    <message>
        <source>Place conferences at top of friend list</source>
        <translation>Colocar los grupos al comienzo de la lista de amigos</translation>
    </message>
    <message>
        <source>Your contact list will be shown in compact mode (small avatars, tabular view).</source>
        <comment>toolTip for compact layout setting</comment>
        <translation>Tu lista de contactos se mostrará en modo compacto (avatares pequeños, vista tabular).</translation>
    </message>
    <message>
        <source>Compact contact list</source>
        <translation>Lista compacta de amigos</translation>
    </message>
    <message>
        <source>Multiple windows mode</source>
        <translation>Modo multiventana</translation>
    </message>
    <message>
        <source>Open each chat in an individual window</source>
        <translation>Abrir una nueva ventana para cada chat</translation>
    </message>
    <message>
        <source>Emoticons</source>
        <translation>Emoticones</translation>
    </message>
    <message>
        <source>Use emoticons</source>
        <translation>Utilizar emoticones</translation>
    </message>
    <message>
        <source>Emoticon size:</source>
        <translation>Tamaño de emoticon:</translation>
    </message>
    <message>
        <source> px</source>
        <translation> px</translation>
    </message>
    <message>
        <source>Theme</source>
        <translation>Tema</translation>
    </message>
    <message>
        <source>Style:</source>
        <translation>Estilo:</translation>
    </message>
    <message>
        <source>Theme color:</source>
        <translation>Color del tema:</translation>
    </message>
    <message>
        <source>Timestamp format:</source>
        <translation>Formato de las marcas temporales:</translation>
    </message>
    <message>
        <source>Date format:</source>
        <translation>Formato de la fecha:</translation>
    </message>
    <message>
        <source>Use identicons instead of empty avatars</source>
        <translation>Utilice identicones en lugar de avatares vacíos</translation>
    </message>
    <message>
        <source>Show a notification when you receive a new message, call, or friend request and the window is not selected.</source>
        <comment>tooltip for Notify setting</comment>
        <translation>Mostrar una notificación cuando recibas un nuevo mensaje, llamada o solicitud de amistad y la ventana no esté seleccionada.</translation>
    </message>
    <message>
        <source>Notify</source>
        <translation>Notificar</translation>
    </message>
    <message>
        <source>Conferences only notify when mentioned</source>
        <translation>Los grupos solo te notifican cuando seas mencionado</translation>
    </message>
    <message>
        <source>Play sound</source>
        <translation>Reproducir audio</translation>
    </message>
    <message>
        <source>Play sound while Busy</source>
        <translation>Reproducir sonido mientras Ocupado</translation>
    </message>
    <message>
        <source>Notify via desktop notifications</source>
        <translation>Notificar a través de notificaciones de escritorio</translation>
    </message>
    <message>
        <source>Hide message sender and contents</source>
        <translation>Ocultar el remitente y el contenido del mensaje</translation>
    </message>
    <message>
        <source>Use colored nicknames in conferences</source>
        <translation>Utilizar apodos coloridos en los grupos</translation>
    </message>
    <message>
        <source>Only notify about new messages in conferences when your nickname is mentioned.</source>
        <comment>toolTip for Conferences only notify when mentioned</comment>
        <translation>Sólo notificar sobre nuevos mensajes en los chat de grupo cuando seas mencionado.</translation>
    </message>
    <message>
        <source>If checked, conferences will be placed at the top of the friends list, otherwise, they&apos;ll be placed below online friends.</source>
        <comment>toolTip for conference positioning</comment>
        <translation>Si está marcada, los chats de grupo se colocarán en la parte superior de la lista de amigos, de lo contrario, se colocarán debajo de los amigos en línea.</translation>
    </message>
    <message>
        <source>If enabled, every contact without an avatar will have a generated icon based on their Tox ID instead of the default picture. Requires restart to apply.</source>
        <comment>toolTip for show identicons</comment>
        <translation>Si activado, todos los contactos sin avatar tendrán un icono generado basado en su ID de Tox en lugar de la imagen por defecto. Requiere reiniciar para aplicarlo.</translation>
    </message>
    <message>
        <source>Smiley pack:</source>
        <extracomment>Text on smiley pack label</extracomment>
        <translation>Paquete de emoticones:</translation>
    </message>
    <message>
        <source>If disabled, mute notification sounds when status is Busy (but still show a notification)</source>
        <translation>Si está deshabilitado, la notificación silenciada suena cuando el estado es Ocupado (pero aún muestra una notificación)</translation>
    </message>
    <message>
        <source>Use desktop notifications, e.g. in a notification center or at the system tray. Without this, the notification will only be visible as a flashing tray icon.</source>
        <translation>Utilice notificaciones de escritorio, por ejemplo en un centro de notificaciones o en la bandeja del sistema. Sin esto, la notificación sólo será visible como un icono de bandeja parpadeante.</translation>
    </message>
    <message>
        <source>Only show &quot;new message&quot; without showing potentially secret information in desktop notifications.</source>
        <translation>Muestra solo &quot;mensaje nuevo&quot; sin mostrar información potencialmente secreta en las notificaciones de escritorio.</translation>
    </message>
    <message>
        <source>Split friend list and chat window into separately moveable windows.</source>
        <translation>Dividir la lista de amigos y chat ventana en ventanas móviles por separado.</translation>
    </message>
    <message>
        <source>Display textual emojis as colorful pictures instead of text or black/white font-rendered emojis.</source>
        <translation>Mostrar emojis textuales como imágenes coloridas en lugar de texto o emojis de fuentes en blanco o negro.</translation>
    </message>
    <message>
        <source>Select which set of pictures to use when rendering emojis.</source>
        <translation>Seleccionar qué conjunto de imágenes utilizar al renderizar emojis.</translation>
    </message>
    <message>
        <source>Size in pixels of an emoji picture. Select something similar to your base font size.</source>
        <translation>Tamaño en píxeles de una imagen emoji. Seleccione algo similar al tamaño de fuente base.</translation>
    </message>
    <message>
        <source>Base style to use for the UI. Fusion is recommended as it works best with qTox theming.</source>
        <translation>Estilo base que se utilizará en la interfaz de usuario. Se recomienda Fusion ya que funciona mejor con la temática qTox.</translation>
    </message>
    <message>
        <source>UI color theme. Use this to select dark mode.</source>
        <translation>Tema de color de la interfaz de usuario. Úselo para seleccionar el modo oscuro.</translation>
    </message>
    <message>
        <source>If disabled, use basic system tray notifications. Otherwise, try to use the notification backend of your desktop environment. Disable this if you observe issues with desktop notifications.</source>
        <translation>Si está desactivada, utilice las notificaciones básicas de la bandeja del sistema. De lo contrario, intente utilizar el backend de notificaciones de su entorno de escritorio. Desactívalo si observas problemas con las notificaciones del escritorio.</translation>
    </message>
    <message>
        <source>Use system-specific notification backend if available</source>
        <translation>Utilizar el backend de notificación específico del sistema si está disponible</translation>
    </message>
    <message>
        <source>Show previews for sent and received images in chats. Hover over the inline preview to display a larger preview.</source>
        <comment>tooltip for Image preview setting</comment>
        <translation>Muestra vistas previas de imágenes enviadas y recibidas en los chats. Pase el cursor sobre la vista previa en línea para mostrar una vista previa más grande.</translation>
    </message>
    <message>
        <source>Image preview</source>
        <translation>Vista previa de imagen</translation>
    </message>
    <message>
        <source>Maximum number of messages (per conversation) loaded from chat history.
Decrease this to improve performance. A too low number here may cause the
scroll bar to disappear.</source>
        <translation>Número máximo de mensajes (por conversación) cargados desde el historial de chat.
Disminuya esto para mejorar el rendimiento. Un número demasiado bajo aquí
puede hacer que desaparezca la barra de desplazamiento.</translation>
    </message>
    <message>
        <source>Maximum chat log view size</source>
        <translation>Tamaño máximo de visualización del registro de chat</translation>
    </message>
    <message>
        <source>Number of messages to load from the chat history when scrolling. A too low
number here may cause the scroll bar to disappear.</source>
        <translation>Número de mensajes a cargar desde el historial de chat al desplazarse. Un
número demasiado bajo aquí puede hacer que desaparezca la barra de
desplazamiento.</translation>
    </message>
    <message>
        <source>Chat log chunk size</source>
        <translation>Tamaño del fragmento del registro de chat</translation>
    </message>
    <message>
        <source>Chat log:</source>
        <translation>Registro de conversaciones:</translation>
    </message>
    <message>
        <source>Hide suffix after NULL symbol</source>
        <translation>Ocultar sufijo tras símbolo NULO</translation>
    </message>
</context>
<context>
    <name>Widget</name>
    <message>
        <source>Online</source>
        <translation>Conectados</translation>
    </message>
    <message>
        <source>Online</source>
        <comment>Button to set your status to &apos;Online&apos;</comment>
        <translation>Conectado</translation>
    </message>
    <message>
        <source>Away</source>
        <comment>Button to set your status to &apos;Away&apos;</comment>
        <translation>Ausente</translation>
    </message>
    <message>
        <source>Busy</source>
        <comment>Button to set your status to &apos;Busy&apos;</comment>
        <translation>Ocupado</translation>
    </message>
    <message>
        <source>Create new conference...</source>
        <translation>Crear un nuevo grupo...</translation>
    </message>
    <message>
        <source>Create new circle...</source>
        <translation>Agregar un nuevo círculo...</translation>
    </message>
    <message>
        <source>By Name</source>
        <translation>Por nombre</translation>
    </message>
    <message>
        <source>By Activity</source>
        <translation>Por actividad</translation>
    </message>
    <message>
        <source>All</source>
        <translation>Todos</translation>
    </message>
    <message>
        <source>Offline</source>
        <translation>Desconectados</translation>
    </message>
    <message>
        <source>Friends</source>
        <translation>Amigos</translation>
    </message>
    <message>
        <source>Conferences</source>
        <translation>Grupos</translation>
    </message>
    <message>
        <source>Search Contacts</source>
        <translation>Buscar amigos</translation>
    </message>
    <message>
        <source>File</source>
        <translation>Archivo</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Editar</translation>
    </message>
    <message>
        <source>Filter...</source>
        <translation>Filtrar...</translation>
    </message>
    <message>
        <source>Contacts</source>
        <translation>Amigos</translation>
    </message>
    <message>
        <source>Your name</source>
        <translation>Tu nombre</translation>
    </message>
    <message>
        <source>Status</source>
        <translation>Estado</translation>
    </message>
    <message>
        <source>Logout</source>
        <comment>Tray action menu to logout user</comment>
        <translation>Cerrar sesión</translation>
    </message>
    <message>
        <source>Show</source>
        <comment>Tray action menu to show qTox window</comment>
        <translation>Mostrar</translation>
    </message>
    <message>
        <source>Add friend</source>
        <comment>title of the window</comment>
        <translation>Agregar amigo</translation>
    </message>
    <message>
        <source>Conference invites</source>
        <comment>title of the window</comment>
        <translation>Invitaciones a grupos</translation>
    </message>
    <message>
        <source>File transfers</source>
        <comment>title of the window</comment>
        <translation>Transferencias de archivos</translation>
    </message>
    <message>
        <source>Settings</source>
        <comment>title of the window</comment>
        <translation>Opciones</translation>
    </message>
    <message>
        <source>My profile</source>
        <comment>title of the window</comment>
        <translation>Mi perfil</translation>
    </message>
    <message>
        <source>Toxcore failed to start, the application will terminate after you close this message.</source>
        <translation>Se produjo un error al iniciar toxcore; el programa terminará al cerrar este mensaje.</translation>
    </message>
    <message>
        <source>Toxcore failed to start with your proxy settings. qTox cannot run; please modify your settings and restart.</source>
        <comment>popup text</comment>
        <translation>Se produjo un error al iniciar toxcore con la configuración actual de proxy. Por favor modifica la configuración y reinicia qTox.</translation>
    </message>
    <message>
        <source>Couldn&apos;t send friend request</source>
        <translation>No se pudo enviar la solicitud de amistad</translation>
    </message>
    <message numerus="yes">
        <source>%n new friend request(s)</source>
        <translation>
            <numerusform>%n nueva solicitud de amistad</numerusform>
            <numerusform>%n nuevas solicitudes de amistad</numerusform>
        </translation>
    </message>
    <message numerus="yes">
        <source>%n new conference invite(s)</source>
        <translation>
            <numerusform>%n nueva invitación de grupo</numerusform>
            <numerusform>%n nuevas invitaciones de grupo</numerusform>
        </translation>
    </message>
    <message>
        <source>Exit</source>
        <comment>Tray action menu to exit Tox</comment>
        <translation>Salir</translation>
    </message>
    <message>
        <source>Change status</source>
        <translation>Cambiar estado</translation>
    </message>
    <message>
        <source>Edit profile</source>
        <translation>Editar perfil</translation>
    </message>
    <message>
        <source>Logout</source>
        <translation>Cerrar sesión</translation>
    </message>
    <message>
        <source>Add contact...</source>
        <translation>Agregar contacto...</translation>
    </message>
    <message>
        <source>Next conversation</source>
        <translation>Próxima conversación</translation>
    </message>
    <message>
        <source>Previous conversation</source>
        <translation>Conversación previa</translation>
    </message>
    <message>
        <source>Debug</source>
        <comment>title of the window</comment>
        <translation>Depurar</translation>
    </message>
</context>
</TS>
